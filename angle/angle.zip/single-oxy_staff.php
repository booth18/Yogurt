<?php
/**
 * Default page template
 *
 * @package Angle
 * @subpackage Frontend
 * @since 0.1
 *
 * @copyright (c) 2014 Oxygenna.com
 * @license http://wiki.envato.com/support/legal-terms/licensing-terms/
 * @version 1.1.0
 */

get_header();
get_template_part('partials/content', 'staff-single');
get_footer();