<?php
/**
 * Main functions file
 *
 * @package Angle
 * @subpackage Frontend
 * @since 0.1
 *
 * @copyright (c) 2014 Oxygenna.com
 * @license http://wiki.envato.com/support/legal-terms/licensing-terms/
 * @version 1.1.0
 */

// create defines
define( 'THEME_NAME', 'Angle' );
define( 'THEME_SHORT', 'angle' );

define( 'OXY_THEME_DIR', get_template_directory() . '/' );
define( 'OXY_THEME_URI', get_template_directory_uri() . '/' );

// include extra theme specific code
include OXY_THEME_DIR . 'inc/frontend.php';
include OXY_THEME_DIR . 'inc/modules/tgm-plugin/plugin-options.php';
include OXY_THEME_DIR . 'inc/woocommerce.php';

// create theme
if( class_exists('OxyTheme') ) {
    global $oxy_theme;
    $oxy_theme = new OxyTheme(
        array(
            'text_domain'       => 'angle-td',
            'admin_text_domain' => 'angle-admin-td',
            'min_wp_ver'        => '3.4',
            'sidebars' => array(
                'sidebar' => array( 'Sidebar', '' ),
            ),
            'widgets' => array(
                'Swatch_twitter' => 'swatch_twitter.php',
                'Swatch_social'   => 'swatch_social.php',
                'Swatch_wpml_language_selector'  => 'swatch_wpml_language_selector.php',
            ),
            'shortcodes' => false,
        )
    );

    include OXY_THEME_DIR . 'inc/custom-posts.php';
    include OXY_THEME_DIR . 'inc/options/shortcodes/shortcodes.php';
    include OXY_THEME_DIR . 'inc/options/widgets/default_overrides.php';

    if( is_admin() ) {
        include OXY_THEME_DIR . 'inc/options/shortcodes/create-shortcode-options.php';
        include OXY_THEME_DIR . 'inc/backend.php';
        include OXY_THEME_DIR . 'inc/theme-metaboxes.php';
        include OXY_THEME_DIR . 'inc/visual-composer.php';
    }
}

function oxy_activate_theme( $theme ) {
    // if no swatches are installed then install the default swatches
    // remove old default swatches
    $swatches = get_posts( array(
        'post_type'      => 'oxy_swatch',
        'meta_key'       => THEME_SHORT . '_default_swatch',
        'posts_per_page' => '-1'
    ));
    if( empty( $swatches ) ) {
        update_option( THEME_SHORT . '_install_swatches', true );
    }
}
add_action( 'after_switch_theme', 'oxy_activate_theme' );
