<svg class="decor hidden-xs hidden-sm" height="100%" preserveaspectratio="none" version="1.1" viewbox="0 0 100 100" width="100%" xmlns="http://www.w3.org/2000/svg">
  <path d="M0 0 L2 40 L4 0 L6 40 L8 0 L10 40 L12 0 L14 40 L16 0 L18 40 L20 0 L22 40 L24 0 L26 40 L28 0 L30 40 L32 0 L34 40 L36 0 L38 40 L40 0 L42 40 L44 0 L46 40 L48 0 L50 40 L52 0 L54 40 56 0 L58 40 L60 0 L62 40 L64 0 L66 40 L68 0 L70 40 L72 0 L74 40 L76 0 L78 40 L80 0 L82 40 L84 0 L86 40 L88 0 L90 40 L92 0 L94 40 L96 0 L98 40 L100 0  " stroke-width="0"></path>
</svg>
<svg class="decor visible-xs visible-sm" height="100%" preserveaspectratio="none" version="1.1" viewbox="0 0 100 100" width="100%" xmlns="http://www.w3.org/2000/svg">
  <path d="M0 0 L5 40 L10 0 L15 40 L20 0 L25 40 L30 0 L35 40 L40 0 L45 40 L50 0 L55 40 L60 0 L65 40 L70 0 L75 40 L80 0 L85 40 L90 0 L95 40 L100 0"></path>
</svg>
