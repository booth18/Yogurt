<svg class="decor" height="60px" preserveaspectratio="none" style="height: 60px !important;" version="1.1" viewbox="0 0 100 100" width="60px" xmlns="http://www.w3.org/2000/svg">
  <path d="M0 25 L100 25" stroke-width="1"></path>
  <path d="M0 75 L100 75" stroke-width="1"></path>
</svg>
