<svg class="decor" height="100%" preserveaspectratio="none" version="1.1" viewbox="0 0 100 100" width="100%" xmlns="http://www.w3.org/2000/svg">
  <path d="M-5 0 Q 0 80 5 0 Z M0 0 Q 5 100 10 0 M5 0 Q 10 70 15 0 M10 0 Q 15 90 20 0 M15 0 Q 20 70 25 0 M20 0 Q 25 90 30 0 M25 0 Q 30 80 35 0 M30 0 Q 35 70 40 0 M35 0 Q 40 90 45 0 M40 0 Q 45 50 50 0 M45 0 Q 50 80 55 0 M50 0 Q 55 60 60 0 M55 0 Q 60 40 65 0 M60 0 Q 65 50 70 0 M65 0 Q 70 80 75 0 M70 0 Q 75 45 80 0 M75 0 Q 80 70 85 0 M80 0 Q 85 80 90 0 M85 0 Q 90 50 95 0 M90 0 Q 95 75 100 0 M95 0 Q 100 85 105 0 Z" stroke-width="0" ></path>
</svg>
