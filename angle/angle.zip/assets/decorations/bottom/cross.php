<svg class="decor" height="60px" preserveaspectratio="none" style="height: 60px !important;" version="1.1" viewbox="0 0 100 100" width="60px" xmlns="http://www.w3.org/2000/svg">
  <path d="M50 0 L50 100" stroke-width="1"></path>
  <path d="M0 50 L100 50" stroke-width="1"></path>
</svg>
