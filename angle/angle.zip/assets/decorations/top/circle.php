<svg class="decor" height="120px" preserveaspectratio="none" style="height: 120px !important;" version="1.1" viewbox="0 0 100 100" width="120px" xmlns="http://www.w3.org/2000/svg">
  <circle cx="50" cy="50" r="50" stroke-width = "0"/>
</svg>
